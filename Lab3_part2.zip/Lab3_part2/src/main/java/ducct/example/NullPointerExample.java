package ducct.example;

import java.util.Optional;

public class NullPointerExample {
    public static void main(String[] args) {
        String text = "Hello";  // <-- Gán giá trị hợp lệ (không null)

        Optional<String> opt = Optional.of(text);
        if (!opt.get().isEmpty()) {
            System.out.println("Text is not empty");
        } else {
            System.out.println("Text is null hoặc rỗng");
        }
    }
}
