package ducct.example;

interface Drawable {

    void draw();
}

class Circle implements Drawable {
    @Override

    public void draw() {
        System.out.println("Vẽ hình tròn");
    }
}

class Maindrawable {

    public static void main(String[] args) {

        Drawable d = new Circle();

        d.draw(); // Output: Vẽ hình tròn
    }
}