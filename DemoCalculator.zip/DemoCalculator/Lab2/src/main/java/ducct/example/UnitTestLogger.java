package ducct.example;

import java.io.FileWriter;
import java.io.IOException;

public class UnitTestLogger {
    private static final String FILE_PATH = "UnitTest.csv";

    public static void logResult(String username, String password, String email, boolean expected, boolean actual) {
        try (FileWriter writer = new FileWriter(FILE_PATH, true)) {
            writer.write(String.format("%s,%s,%s,%s,%s\n",
                    username, password, email, expected, actual));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
