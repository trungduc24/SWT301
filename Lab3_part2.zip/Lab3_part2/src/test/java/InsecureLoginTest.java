import org.junit.jupiter.api.Test;
import ducct.example.InsecureLogin;

class InsecureLoginTest {

    @Test
    void testLoginFail() {
        InsecureLogin.login("user", "wrongpassword");
    }

    @Test
    void testPrintUserInfo() {
        InsecureLogin insecureLogin = new InsecureLogin();
        insecureLogin.printUserInfo("John Doe");
    }
}