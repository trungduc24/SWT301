package ducct.example;

import java.util.logging.Logger;

public class CatchGenericExceptionExample {
    private static final Logger logger = Logger.getLogger(CatchGenericExceptionExample.class.getName());

    public static void main(String[] args) {


        logger.warning("Biến 's' đang null, không thể gọi phương thức length().");
    }
}
