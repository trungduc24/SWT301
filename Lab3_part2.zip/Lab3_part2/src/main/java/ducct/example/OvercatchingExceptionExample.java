package ducct.example;

public class OvercatchingExceptionExample {
    public static void main(String[] args) {
        try {
            int[] arr = new int[5];
            for (int i = 0; i < arr.length; i++) {
                arr[i] = i * 10;
            }

            // Truy cập phần tử hợp lệ
            System.out.println("Phần tử thứ 0: " + arr[0]);
            System.out.println("Phần tử cuối: " + arr[arr.length - 1]);

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Lỗi chỉ số mảng: " + e.getMessage());
        }
    }
}
