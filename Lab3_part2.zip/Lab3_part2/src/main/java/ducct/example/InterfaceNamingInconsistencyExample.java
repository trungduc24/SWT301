package ducct.example;

interface LoginHandler {
    void login(String username, String password);
}

class SimpleLogin implements LoginHandler {
    @Override
    public void login(String username, String password) {
        System.out.println("Đăng nhập với username: " + username + " và password: " + password);
    }
}

class MainInterfaceFielMod {
    public static void main(String[] args) {
        LoginHandler handler = new SimpleLogin();
        handler.login("admin", "1234");
    }
}
