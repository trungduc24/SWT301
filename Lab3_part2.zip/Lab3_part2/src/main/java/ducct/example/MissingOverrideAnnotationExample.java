package ducct.example;

class Animal {
    void speak() {
        System.out.println("Animal speaks");
    }
}

class Dog extends Animal {
    @Override
    void speak() {
        System.out.println("Dog barks");
    }
}

class Mainspeak {
    public static void main(String[] args) {
        Animal a = new Dog();
        a.speak();  // Output: Dog barks
    }
}
