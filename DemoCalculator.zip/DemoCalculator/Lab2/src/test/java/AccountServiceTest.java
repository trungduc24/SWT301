package ducct.example;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import static org.junit.jupiter.api.Assertions.*;

public class AccountServiceTest {

    private final AccountService accountService = new AccountService();

    /**
     * Test đăng ký tài khoản dựa trên dữ liệu CSV
     * File CSV đặt trong src/test/resources/test-data.csv
     */
    @ParameterizedTest
    @CsvFileSource(resources = "/test-data.csv", numLinesToSkip = 1)
    void testRegisterAccount(String username, String password, String email, boolean expected) {
        boolean actual = accountService.registerAccount(username, password, email);

        // Ghi kết quả test ra file UnitTest.csv
        UnitTestLogger.logResult(username, password, email, expected, actual);

        assertEquals(expected, actual, "Kiểm tra đăng ký tài khoản cho user: " + username);
    }
}
