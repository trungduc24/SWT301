package ducct.example;

final class Constants {
    public static final int MAX_USERS = 100;
}

public class InterfaceFieldModificationExample {
    public static void main(String[] args) {
        System.out.println("Số người dùng tối đa: " + Constants.MAX_USERS);
    }
}
