package ducct.example;

class User {
    private final String name;
    private int age;

    // Constructor
    public User(String name, int age) {
        this.name = name;
        setAge(age); // kiểm tra luôn trong setter
    }

    // Getter
    public String getName() {
        return name;
    }

    public void setAge(int age) {
        if (age >= 0) {
            this.age = age;
        } else {
            System.out.println("Tuổi không hợp lệ!");
        }
    }

    public void display() {
        System.out.println("Name: " + name + ", Age: " + age);
    }
}

class MainVioalation {
    public static void main(String[] args) {
        User user = new User("Alice", 25);
        user.display();

        user.setAge(-5); // sẽ in lỗi
    }
}
