package ducct.example;

// Interface để tách phụ thuộc
interface Printable {
    void print(String message);
}

// Lớp in ra console
class ConsolePrinter implements Printable {
    @Override
    public void print(String message) {
        System.out.println(message);
    }
}

// Lớp Report giảm phụ thuộc
class Report {
    private static final String DEFAULT_MESSAGE = "Generating report...";
    private final Printable printer;

    public Report(Printable printer) {
        this.printer = printer;
    }

    void generate() {
        printer.print(DEFAULT_MESSAGE);
    }
}

// Lớp chạy chính
class MainTingCoupling {
    public static void main(String[] args) {
        Printable printer = new ConsolePrinter();
        Report report = new Report(printer);
        report.generate(); // Sử dụng đúng → không còn cảnh báo "dead code"
    }
}
