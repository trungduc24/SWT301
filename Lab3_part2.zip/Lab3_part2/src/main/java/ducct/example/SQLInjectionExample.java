package ducct.example;

import java.sql.*;
import java.util.logging.*;

public class SQLInjectionExample {

    private static final Logger logger = Logger.getLogger(SQLInjectionExample.class.getName());

    public static void main(String[] args) {
        String userInput = "' OR '1'='1";  // dữ liệu đầu vào giả định

        String url = "jdbc:mysql://localhost:3306/mydb";
        String username = System.getenv("DB_USERNAME");
        String password = System.getenv("DB_PASSWORD");

        String sql = "SELECT username, email FROM users WHERE username = ?";

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, userInput);  // chống SQL Injection

            logger.info("Thực thi truy vấn an toàn");

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String user = rs.getString("username");
                String email = rs.getString("email");
                System.out.println("User: " + user + " | Email: " + email);
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Lỗi khi truy vấn cơ sở dữ liệu", e);
        }
    }
}
