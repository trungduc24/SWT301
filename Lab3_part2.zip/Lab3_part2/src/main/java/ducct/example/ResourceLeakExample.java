package ducct.example;

import java.io.*;
import java.util.logging.*;

public class ResourceLeakExample {

    // Khởi tạo logger
    private static final Logger logger = Logger.getLogger(ResourceLeakExample.class.getName());

    public static void main(String[] args) {
        try (BufferedReader reader = new BufferedReader(new FileReader("data.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Đã xảy ra lỗi khi đọc file", e);
        }
    }
}
